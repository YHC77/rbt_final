# Will be tested only with strictly positive integers for
# total_nb_of_letters and height.
#
# <BLANKLINE> is not output by the program, but
# doctest's way to refer to an empty line.
# For instance,
#    A
#    B
#    C
#    <BLANKLINE>
#    <BLANKLINE>
# means that 5 lines are output: first a line with A,
# then a line with B, then a line with C,
# and then 2 empty lines.
#
# Note that no line has any trailing space.

def f(total_nb_of_letters, height):
    '''
    >>> f(4, 1)
    ABCD
    >>> f(3, 5)
    A
    B
    C
    <BLANKLINE>
    <BLANKLINE>
    >>> f(4, 2)
    AD
    BC
    >>> f(5, 2)
    ADE
    BC
    >>> f(6, 2)
    ADE
    BCF
    >>> f(7, 2)
    ADE
    BCFG
    >>> f(8, 2)
    ADEH
    BCFG
    >>> f(9, 2)
    ADEHI
    BCFG
    >>> f(17,5)
    AJK
    BIL
    CHM
    DGNQ
    EFOP
    >>> f(100, 6)
    ALMXYJKVWHITUFGRS
    BKNWZILUXGJSVEHQT
    CJOVAHMTYFKRWDIPU
    DIPUBGNSZELQXCJOV
    EHQTCFORADMPYBKN
    FGRSDEPQBCNOZALM
    '''
    # INSERT YOUR CODE HERE
    for row in range(height):
        output = ''

        # Add letters from full cycles
        for cycle in range(full_cycles):
            index1 = cycle * (2 * height - 2) + row
            index2 = (cycle + 1) * (2 * height - 2) - row - 1
            output += letters[index1] + (letters[index2] if row != 0 and row != height - 1 else '')

        # Add remaining letters
        if remaining_letters > row:
            output += letters[full_cycles * (2 * height - 2) + row]
        if remaining_letters > 2 * height - 2 - row - 1 > 0:
            output += letters[full_cycles * (2 * height - 2) + remaining_letters - row - 1]

        # Print the row
        print(output)
if __name__ == '__main__':
    import doctest

    doctest.testmod()
